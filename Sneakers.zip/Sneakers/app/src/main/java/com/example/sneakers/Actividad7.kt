package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad7)
    }
    fun actividad41(view: View){
        val intent = Intent(this, Actividad41()::class.java)
        startActivity(intent)
    }
}
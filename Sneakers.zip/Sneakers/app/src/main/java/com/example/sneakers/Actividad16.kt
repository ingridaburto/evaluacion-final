package com.example.sneakers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Actividad16 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad16)
    }
}
package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad5)
    }
    fun actividad16(view: View){
        val intent = Intent(this, Actividad16()::class.java)
        startActivity(intent)
    }
    fun actividad17(view: View){
        val intent = Intent(this, Actividad17()::class.java)
        startActivity(intent)
    }
    fun actividad18(view: View){
        val intent = Intent(this, Actividad18()::class.java)
        startActivity(intent)
    }
    fun actividad19(view: View){
        val intent = Intent(this, Actividad19()::class.java)
        startActivity(intent)
    }
    fun actividad20(view: View){
        val intent = Intent(this, Actividad20()::class.java)
        startActivity(intent)
    }
    fun actividad21(view: View){
        val intent = Intent(this, Actividad21()::class.java)
        startActivity(intent)
    }
    fun actividad22(view: View){
        val intent = Intent(this, Actividad22()::class.java)
        startActivity(intent)
    }
    fun actividad23(view: View){
        val intent = Intent(this, Actividad23()::class.java)
        startActivity(intent)
    }
    fun actividad39(view: View){
        val intent = Intent(this, Actividad39()::class.java)
        startActivity(intent)
    }
    fun actividad40(view: View){
        val intent = Intent(this, Actividad40()::class.java)
        startActivity(intent)
    }
}
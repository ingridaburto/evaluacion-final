package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad4)
    }
    fun actividad7(view: View){
        val intent = Intent(this, Actividad7()::class.java)
        startActivity(intent)
    }
    fun actividad8(view: View){
        val intent = Intent(this, Actividad8()::class.java)
        startActivity(intent)
    }
    fun actividad10(view: View){
        val intent = Intent(this, Actividad10()::class.java)
        startActivity(intent)
    }
    fun actividad11(view: View){
        val intent = Intent(this, Actividad11()::class.java)
        startActivity(intent)
    }
    fun actividad12(view: View){
        val intent = Intent(this, Actividad12()::class.java)
        startActivity(intent)
    }
    fun actividad13(view: View){
        val intent = Intent(this, Actividad13()::class.java)
        startActivity(intent)
    }
    fun actividad14(view: View){
        val intent = Intent(this, Actividad14()::class.java)
        startActivity(intent)
    }
    fun actividad15(view: View){
        val intent = Intent(this, Actividad15()::class.java)
        startActivity(intent)
    }
    fun actividad39(view: View){
        val intent = Intent(this, Actividad39()::class.java)
        startActivity(intent)
    }
    fun actividad40(view: View){
        val intent = Intent(this, Actividad40()::class.java)
        startActivity(intent)
    }

}
package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad9 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad9)
    }
    fun actividad32(view: View) {
        val intent = Intent(this,Actividad32()::class.java)
        startActivity(intent)
    }
    fun actividad33(view: View) {
        val intent = Intent(this,Actividad33()::class.java)
        startActivity(intent)
    }
    fun actividad34(view: View) {
        val intent = Intent(this,Actividad34()::class.java)
        startActivity(intent)
    }
    fun actividad35(view: View) {
        val intent = Intent(this,Actividad35()::class.java)
        startActivity(intent)
    }
    fun actividad36(view: View) {
        val intent = Intent(this,Actividad36()::class.java)
        startActivity(intent)
    }
    fun actividad37(view: View) {
        val intent = Intent(this,Actividad37()::class.java)
        startActivity(intent)
    }
    fun actividad38(view: View) {
        val intent = Intent(this,Actividad38()::class.java)
        startActivity(intent)
    }
    fun actividad39(view: View){
        val intent = Intent(this, Actividad39()::class.java)
        startActivity(intent)
    }
    fun actividad40(view: View){
        val intent = Intent(this, Actividad40()::class.java)
        startActivity(intent)
    }
}
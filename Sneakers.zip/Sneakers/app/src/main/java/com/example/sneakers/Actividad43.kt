package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad43 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad43)
    }
    fun actividad44(view: View){
        val intent = Intent(this, Actividad44()::class.java)
        startActivity(intent)
    }

}
package com.example.sneakers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Actividad6 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad6)
    }
    fun actividad24(view: View) {
        val intent = Intent(this,Actividad24()::class.java)
        startActivity(intent)
    }
    fun actividad25(view: View) {
        val intent = Intent(this,Actividad25()::class.java)
        startActivity(intent)
    }
    fun actividad26(view: View) {
        val intent = Intent(this,Actividad26()::class.java)
        startActivity(intent)
    }
    fun actividad27(view: View) {
        val intent = Intent(this,Actividad27()::class.java)
        startActivity(intent)
    }
    fun actividad28(view: View) {
        val intent = Intent(this,Actividad28()::class.java)
        startActivity(intent)
    }
    fun actividad29(view: View) {
        val intent = Intent(this,Actividad29()::class.java)
        startActivity(intent)
    }
    fun actividad30(view: View) {
        val intent = Intent(this,Actividad30()::class.java)
        startActivity(intent)
    }
    fun actividad31(view: View) {
        val intent = Intent(this,Actividad31()::class.java)
        startActivity(intent)
    }
    fun actividad39(view: View){
        val intent = Intent(this, Actividad39()::class.java)
        startActivity(intent)
    }
    fun actividad40(view: View){
        val intent = Intent(this, Actividad40()::class.java)
        startActivity(intent)
    }
}